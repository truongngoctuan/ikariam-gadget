﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using IkariamFramework.DAOIkariamFramework;
using IkariamFramework.DTOIkariamFramework;
using System.Runtime.InteropServices;

namespace IkariamFramework.BUSIkariamFramework
{
    [ComVisible(true)]
    public class BUSResearch
    {
        public static DTOResearch Get()
        {
            if (Gloval.Database.Account.Research == null)
            {
                return ForceUpdate();
            }

            return Gloval.Database.Account.Research;
        }


        public static DTOResearch ForceUpdate()
        {
            //chuyen trang
            DAOAdvisor.GoToadvResearch();
            Gloval.Database.Account.DTResearch = DateTime.Now;

            //lay sc point
            DAOResearch.GetCurrentResearchScientists();

            //lay cac thong tin 4 truong phai kia
            DAOResearch.GetInfomation4BrandOfResearch();

            return Gloval.Database.Account.Research;
        }

        public static void CalculateFromLocalData()
        {
            DateTime dtnew = DateTime.Now;
            DTOResearch ct = BUSResearch.Get();
            TimeSpan tp = new TimeSpan(dtnew.Ticks - Gloval.Database.Account.DTResearch.Ticks);

            //cap nhat dan - townhall
            ct.ResearchPoints += (long)BaseFunction.updateValue(ct.ResearchPointsPerHour, (float)tp.TotalSeconds);

            //cap nhat lai thoi gian
            Gloval.Database.Account.DTResearch = dtnew;
            Gloval.Database.Account.Research = ct;
        }
    }
}
